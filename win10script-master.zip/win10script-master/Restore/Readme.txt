Run this script in powershell.

This restore script pops up a GUI that lets you restore what you want to FACTORY DEFAULTS!

   Action Center
   Cortana
   Defender Icon
   Windows Search
   Tray Icons
   Clipboard History
   Location
   Background Apps
