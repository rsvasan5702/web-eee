IMPORTANT INFORMATION:
https://github.com/NaveenResearchTamil/Windows10Debloat_2021
வணக்கம். மேலே கொடுக்கப்பட்டுள்ள லிங்க்கை பயன்படுத்தி புதிய மேம்படுத்தப்பட்ட மென்பொருளை இலவசமாக பெற்று பயன் பெறவும். நன்றி.

முகப்பு:

   இந்த மென்பொருள் பதிப்பானது "விண்டோஸ் 10 இயங்குதளத்தில் தேவையற்ற உள்ளீட்டை நீக்கும் செயலி" என்பதாகும்.

   இது பல்வேறு இலவச மென்பொருட்களின் ஒன்றுசேர்க்கப்பட்ட தொகுப்பு ஆகும். 

   இவை யாவும் நாங்கள் சேவை கொடுக்கும் ஒவ்வொரு கணினியிலும் பயன்படுத்தும் மென்பொருள். 
   
 ----------------
   
 Gaming:
   Gaming-Centric என்ற பக்கத்திற்குள் சென்று அங்கே உள்ள பதிவினை இயக்கவும்.
   
 ----------------

மாற்றங்கள் நீக்கம் Restore: 

   இந்த பதிப்பின் மாற்றங்களை நீக்க, "Restore" என்ற பகுதியில் உள்ள பதிவினை powershell இல் இயக்கவும்.
   
----------------

அம்சங்கள்:

- Dark Mode
- One Command to launch and run
- Chocolatey Install
- O&O Shutup10 CFG and Run
- Added Install Programs
- Added Debloat Microsoft Store Apps
- Full GUI Implementation

----------------

முக்கிய குறிப்பு:
இதை இயக்கம் முன்னர் உங்கள் கணினியை நகல் எடுத்திருப்பது அவசியம். [Running a backup before running the script is highly recommended to revert back if needed]
இது தொடர்பான தொழில்நுட்ப உதவி தேவைபட்டால், மென்பொருளை இயக்கம் பொறியாளர் எவரையேனும் அணுகவும்.


----------------

எனது உள்ளீடு:

தமிழ் விளக்கம் மற்றும் மொழி பெயர்ப்பு.

How To:
YouTube: https://youtu.be/ukwRA1mtZsU

----------------
This project is a fork, Translated with How-To guide | All credits goes to respective opensource script contributors.
See Fork Info for details. Provided "AS-IS" without any guarantee or warranty. 
