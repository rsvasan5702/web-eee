 இந்த மென்பொருள் பதிப்பானது "விண்டோஸ் 10 & 11 இயங்குதளத்தில் தேவையற்ற உள்ளீட்டை நீக்கும் & விளையாட்டை மேம்படுத்தும் செயலி" என்பதாகும்.

   இது பல்வேறு இலவச மென்பொருட்களின் ஒன்றுசேர்க்கப்பட்ட தொகுப்பு ஆகும். 
   இவை யாவும் நாங்கள் சேவை கொடுக்கும் ஒவ்வொரு கணினியிலும் பயன்படுத்தும் மென்பொருள். 
   
 ----------------
   
 Gaming:
   Gaming-Centric என்ற பாகத்திற்குள் சென்று அங்கே உள்ள பதிவினை இயக்கவும்.
   
 ----------------

மாற்றங்கள் நீக்கம் Restore: 

   இந்த பதிப்பின் மாற்றங்களை நீக்க, "Restore" என்ற பகுதியில் உள்ள பதிவினை இயக்கவும்.
   
----------------

முக்கிய குறிப்பு:
இதை இயக்கம் முன்னர் உங்கள் கணினியை நகல் எடுத்திருப்பது அவசியம். [Running a backup before running the script is highly recommended to revert back if needed, though this script does it automatically]
இது தொடர்பான தொழில்நுட்ப உதவி தேவைபட்டால் Youtube செய்முறை விளக்கத்தை பார்க்கவும்.

----------------

# Windows 10 & 11 Debloat 2021
This script is a fork of the culmination of many scripts and gists from github with customizations of my own. I forked this script to be a swiss army knife of Windows tools to optimize machines and to enhance gaming [Checkout "Gaming Focus" Folder].

## Customizations
- Applicaiton Install Wizard has been hidden
- Fully Focused towards optimization and tuning

## Available Features
- Full GUI
- Winget install
- O&O Shutup 10 CFG and Run
- Dark/Light mode
- Semi-configurable

## How to Run

```
General Use: Open the downloaded code, Right click "win10debloat.ps1" and choose "Run With Powershell"
For Gamers: Goto "Gaming Focus" folder and run the win10debloatandgamingtweaks.ps1 and right click to choose "Run With Powershell"
```

Forked From Chris Titus Tech & DaddyMadu
